from django.contrib import admin

from .models import AprendamosDeFuncionCuadratica, Ejercicios, Estudiante, Docente
admin.site.register(AprendamosDeFuncionCuadratica)
admin.site.register(Ejercicios)
admin.site.register(Estudiante)
admin.site.register(Docente)